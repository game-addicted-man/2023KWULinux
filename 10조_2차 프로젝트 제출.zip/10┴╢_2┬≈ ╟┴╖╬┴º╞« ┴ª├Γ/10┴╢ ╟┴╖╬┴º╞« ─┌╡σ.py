import curses
import random
import time

def read_options_from_file(file_path):
    with open(file_path, 'r') as file:
        options = file.read().splitlines()
    return options

def show_menu(stdscr):
    menu_options = ["Start Game (Sentences)", "Start Game (Words)", "Start Game (Long Text)", "Exit"]
    current_option = 0
    curses.curs_set(0)
    stdscr.nodelay(0)
    stdscr.timeout(-1)
    stdscr.keypad(1)
    sh, sw = stdscr.getmaxyx()
    while True:
        stdscr.clear()
        for i, option in enumerate(menu_options):
            x = sw // 2 - len(option) // 2
            y = sh // 2 - len(menu_options) // 2 + i
            if i == current_option:
                stdscr.addstr(y, x, option, curses.A_REVERSE)
            else:
                stdscr.addstr(y, x, option)
        stdscr.refresh()
        key = stdscr.getch()
        if key == curses.KEY_UP:
            current_option = (current_option - 1) % len(menu_options)
        elif key == curses.KEY_LEFT :
            current_option = (current_option - 1) % len(menu_options)
        elif key == curses.KEY_DOWN :
            current_option = (current_option + 1) % len(menu_options)
        elif key == curses.KEY_RIGHT :
            current_option = (current_option + 1) % len(menu_options)
        elif key == ord('\n'):
            if current_option == 0:
                stdscr.clear()
                stdscr.refresh()
                time.sleep(1)  
                start_game(stdscr, True)
            elif current_option == 1:
                stdscr.clear()
                stdscr.refresh()
                time.sleep(1)  
                start_game(stdscr, False)
            elif current_option == 2:
                stdscr.clear()
                stdscr.refresh()
                time.sleep(1)
                start_game_long(stdscr, file_path="long_text.txt")
            elif current_option == 3:
                break

def start_game(stdscr, is_sentence):
    curses.curs_set(0)
    stdscr.nodelay(1)
    stdscr.timeout(100)
    stdscr.keypad(1)
    sh, sw = stdscr.getmaxyx()
    if is_sentence:
        options = [
            "The quick brown fox jumps over the lazy dog.",
            "Hello, world!",
            "Python is awesome!",
            "I love programming.",
            "Keep practicing!",
            "I can do this all day.",
            "C++ and python is great!",
            "Linux programming is fun!",
            "Ubuntu seems odd.",
            "What can I do for you?",
            "Do you loike pancake?",
            "You think programming is fun?"
        ]
    else:
        options = [
            "apple",
            "banana",
            "cherry",
            "orange",
            "grape",
            "melon",
            "gain",
            "begin",
            "sample",
            "absorb",
            "continuous",
            "feel",
            "turn",
            "alarm",
            "cell",
            "pigeon",
            "variety",
            "hang",
            "sand",
            "rush",
            "gasp",
            "difference",
            "grudge"
        ]
    current_option = random.choice(options)
    current_col = (sw - len(current_option)) // 2
    score = 0
    count = 0
    count_right = 0
    start = time.time()
    while True:
        stdscr.clear()
        stdscr.addstr(sh // 2, current_col, current_option)
        stdscr.addstr(0, 0, f"Score: {score}")
        key = stdscr.getch()
        if key != -1:
            if chr(key) == '\\':
                current_option = random.choice(options)
                current_col = (sw - len(current_option)) // 2
            elif key == 27:  # ESC 키
                end = time.time()
                break
            elif chr(key) == current_option[0]:
                current_option = current_option[1:]
                score += 1
                count_right += 1
                if len(current_option) == 0:
                    count += 1
                    current_option = random.choice(options)
                    current_col = (sw - len(current_option)) // 2
            elif key == 24:  # ctrl+x
                score += 50
            else:
                score -= 1
        stdscr.refresh()
        if score < 0 or count == 20:
            end = time.time()
            break
    hit = count_right * 60 / (end-start)
    stdscr.clear()
    stdscr.addstr(sh // 2, (sw - 14) // 2, "Game Over!")
    stdscr.addstr(sh // 2 + 1 ,(sw - 14) // 2, "----------")
    stdscr.addstr(sh // 2 + 2, (sw - 14) // 2, f"Score : {score}")
    stdscr.addstr(sh // 2 + 3, (sw - 14) // 2, f"Time : {end-start:.2f}s")
    stdscr.addstr(sh // 2 + 4, (sw - 14) // 2, f"How fast : {hit:.2f}")
    stdscr.refresh()
    time.sleep(5)
def start_game_long(stdscr, file_path=None):
    curses.curs_set(0)
    stdscr.nodelay(1)
    stdscr.timeout(100)
    stdscr.keypad(1)
    sh, sw = stdscr.getmaxyx()

    if file_path:
        options = read_options_from_file(file_path)
    else:
        options = [
            "The quick brown fox jumps over the lazy dog.",
            "Hello, world!",
            "Python is awesome!",
            "I love programming.",
            "Keep practicing!",
            "I can do this all day.",
            "C++ and Python are great!",
            "Linux programming is fun!",
            "Ubuntu seems odd.",
            "What can I do for you?",
            "Do you like pancakes?",
            "Do you think programming is fun?"
        ]

    current_options = options[:sh-2]  
    current_col = [(sw - len(option)) // 2 for option in current_options]

    score = 0
    count = 0
    count_right = 0
    start = time.time()

    while True:
        stdscr.clear()
        for i, option in enumerate(current_options):
            stdscr.addstr(i, current_col[i], option)    
        

        stdscr.addstr(0, 0, f"Score: {score}")

        key = stdscr.getch()
        if key != -1:
            if chr(key) == '\\':
                current_options = options[:sh-2]
                current_col = [(sw - len(option)) // 2 for option in current_options]
            elif key == 27:  # ESC 키
                end = time.time()
                break
            else:
                wrong_input = True
                for i, option in enumerate(current_options):
                    if option.startswith(chr(key)):
                        current_options[i] = option[1:]
                        score += 1
                        count_right += 1
                        wrong_input = False
                        if len(option) == 1:
                            current_options.pop(i)
                            current_col.pop(i)
                        break
                if wrong_input:
                    score -= 1
        stdscr.refresh()
        
        if score < 0 or len(current_options) == 0:
            end = time.time()
            break
    hit = count_right * 60 / (end-start)
    stdscr.clear()
    stdscr.addstr(sh // 2, (sw - 14) // 2, "Game Over!")
    stdscr.addstr(sh // 2 + 1, (sw - 14) // 2, "----------")
    stdscr.addstr(sh // 2 + 2, (sw - 14) // 2, f"Score : {score}")
    stdscr.addstr(sh // 2 + 3, (sw - 14) // 2, f"Time : {end-start:.2f}s")
    stdscr.addstr(sh // 2 + 4, (sw - 14) // 2, f"How fast : {hit:.2f}")
    stdscr.refresh()
    time.sleep(5)

if __name__ == "__main__":
    curses.wrapper(show_menu)
